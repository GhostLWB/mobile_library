package ObjectFActory;

import communiate.BorrowedItem;
import communiate.StoredItems;

public class ItemFactory {
	public StoredItems makeStoreItem(String cataloge) throws Exception{
		return new StoredItems(cataloge);
	}//end makeStore
	
	public BorrowedItem makeBorrowedItem(String ID) throws Exception{
		return new BorrowedItem(ID);
	}
}
