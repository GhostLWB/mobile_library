package object;
public class Vedio extends Item {


	private String performer;
	private String format;
	private int time;
	public Vedio(String initialcode, String initialpublishTimeString,
			String initialnameString,
			String initialcategory,String initialperformer,String initialformat,int time) {
		super(initialcode, initialpublishTimeString, initialnameString,
				initialcategory);
		this.performer=initialperformer;
		this.format=initialformat;
		this.time=time;
	}
	public String toString()
	{
		return "��Ƶ"+"_"+this.getCode()+"_"+this.getName()+"_"+this.getPublishTime()+"_"+this.getCategory()+"_"+this.getAvaliabe()+"_"+this.time+"_"+this.performer
				+"_"+this.format;
	}
	
}
