package object;
public class SuperAccount extends BorrowerAccount {

	private final boolean isSuper = true;//�Ƿ�Ϊ��������Ա
	
	
	 public SuperAccount(String initialID, String initialname, String initialpassWords) {
		super(initialID, initialname, initialpassWords);	
	}
	

	public boolean getIsSuper() {
		return isSuper;
	}
	
	public String toString(){
		return super.getName()+"_"+super.getID()+"_"+super.getPassWords()+"_"+isSuper;
	}
}
