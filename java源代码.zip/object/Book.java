package object;
public class Book extends Item {


	private String author;
	private int page;
	public Book(String initialcode, String initialpublishTimeString,
			String initialnameString,String initialcategory,String initialauthor
			,int initialpage) {
		super(initialcode, initialpublishTimeString, initialnameString,
				initialcategory);
		this.author=initialauthor;
		this.page=initialpage;
	}

	public String getAuthor() {
		return author;
	}
	public int getPage() {
		return page;
	}
	public String toString()
	{
		return "�鼮"+"_"+this.getCode()+"_"+this.getName()+"_"+this.getPublishTime()+"_"+this.getAvaliabe()+"_"+this.getCategory()
				+"_"+this.getAuthor()+"_"+this.getPage();
	}
}
