package communiate;
import java.util.Iterator;
import java.util.Vector;

import Tools.CommuninateWithFile;
import Tools.MakeItemFromString;
import object.Item;
//��װʱ�������Ŀ���������filename
public class StoredItems {
		
	private String cataloge;
	private Vector<Item> storeItems;
	private CommuninateWithFile communinateWithFile;
	
	//��ɶ�cataloge,path.borrowedItems�ĳ�ʼ��
	public StoredItems(String initialCataloge) throws Exception{
		storeItems = new Vector<Item>();
		cataloge = initialCataloge;
		MatchCatalogeWithStoredItems matchCatalogeWithStoredItems =MatchCatalogeWithStoredItems.getSingleInstance();//��ȡ��IDƥ���·��
		communinateWithFile = new CommuninateWithFile(matchCatalogeWithStoredItems.getMacthedPath(cataloge));
		communinateWithFile.writeDataToFile("", true);//ȷ���ļ�����
		storeItems = new Vector<Item>();
		finishStoredItems();
	}
	
	
	public String getCataloge() {
		return cataloge;
	}
	
	
	
	//��ɶ�storeItems�ĳ�ʼ��
	private void finishStoredItems() throws Exception{
		String[] textLine;
		String text;
		
		text = communinateWithFile.readDataFromFile();
		if(text!=""){
			textLine = text.split("\n");
			for (int i = 0; i < textLine.length; i++) {
				storeItems.add(MakeItemFromString.makeItemFromString(textLine[i]));
			}//endfor
		}//endif
	}
	
	//��ñ�����	
	public Iterator<Item> getIterator(){
		return storeItems.iterator();
	}
	
	
	//��storeItems�е�items��ToString
	public String toString(){
		String text = "";
		Iterator<Item> iterator = getIterator();
		while (iterator.hasNext()) {
			Item item = (Item) iterator.next();
			text += item.toString()+"_\n";
		}
		return text;
	}
	//��borrowedItems������items
	public void addItem(Item item) {
		storeItems.add(item);
	}
	//�Ƴ��ض���items
	public boolean removeItem(String ID) {
		
		Item item;
		Iterator<Item> iterator = getIterator();
		
		while (iterator.hasNext()) {
			item = (Item) iterator.next();
			if (item.equals(ID)) {
				iterator.remove();
				return true;
			}
		}
		
		return false;
	}
	//�������ֲ����ض�����Ŀ��
	public Vector<Item> searchItem(String itemName) {
		Item  item;
		Vector<Item> items = new Vector<Item>();
		Iterator<Item> iterator = getIterator();
		
		while (iterator.hasNext()) {
			item = (Item) iterator.next();
			if (item.getName().equals(itemName)) {
				items.add(item);
			}
		}
		return items;
	}
	
	//����Ŀд���ض����ļ���
	public void writeStoredItemsToFile() throws Exception{ 
		String text = toString();
		communinateWithFile.writeDataToFile(text);
	}

	//�ж���Ŀ�Ƿ�Ϊ��
	public boolean isEmpty(){
		if(storeItems.size()==0){
			return true;
		}else{
			return false;
		}//endif
	}
	
	
	//����
	public boolean borrowBook(String code)throws Exception{
		Item item = null;
		Iterator<Item> iterator = getIterator();
		while (iterator.hasNext()) {
			item = (Item) iterator.next();
			if(item.getCode().equals(code)){
				iterator.remove();
				item.setAvaliable(false);
				addItem(item);
				writeStoredItemsToFile();
				return true;
			}//endif
		}//endwhile
		
		return false;
	}//end
	
	//���ݴ���ID����
	public boolean returnBook(String code) throws Exception{
		Iterator<Item> iterator = storeItems.iterator();
		while (iterator.hasNext()) {
			Item item = (Item) iterator.next();
			if(item.getCode().equals(code)){
				iterator.remove();
				item.setAvaliable(true);
				storeItems.add(item);
				writeStoredItemsToFile();
				return true;
			}//endif
		}//endwhile
		
		return false;
	}//end
}