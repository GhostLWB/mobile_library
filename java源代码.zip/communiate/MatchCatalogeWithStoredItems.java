package communiate;
import java.util.Iterator;
import java.util.Vector;

import Tools.CommuninateWithFile;

public class MatchCatalogeWithStoredItems {
	
	private static MatchCatalogeWithStoredItems singleIntance = null;
	private CommuninateWithFile communinateWithFile;
	private Vector<String> textLine ;
	
	private final String filename = ".\\CatalogeWithStoredItems.txt";
	
	
	//��õ���
	public static MatchCatalogeWithStoredItems getSingleInstance() throws Exception{
		if(singleIntance==null){
			return new MatchCatalogeWithStoredItems();
		}else{
			return singleIntance;
		}//endif
	}//end
	
	//���췽��
	private MatchCatalogeWithStoredItems()throws Exception {
		String[] Array;
		String text;
		textLine = new Vector<String>();//��ʼ������
		communinateWithFile = new CommuninateWithFile(filename);
		communinateWithFile.writeDataToFile("",true);//ȷ���ļ�����
		
		text = communinateWithFile.readDataFromFile();
		if(text!=""){
			Array = text.split("\n");
			
				for(int i=0;i<Array.length;i++){
					textLine.add(Array[i]);
				}//endfor
		}//endif
	}
	
	//��ñ�����
	public Iterator<String> getIterator(){
		return textLine.iterator();
	}//end
	
	//��ȡ��catalogƥ���path
	public String getMacthedPath(String cataloge){
		String path = null;
		String[] IdAndPath = null; 
		Iterator<String> iterator =getIterator();
		while (iterator.hasNext()) {
			String string = (String) iterator.next();
			IdAndPath =string.split("_");
			if(IdAndPath[0].equals(cataloge)){
				path = IdAndPath[1];
			}
		}
		return path;
	}//end
	
	//�жϷ����Ƿ��Ѿ�����
	public boolean hasACAtaloge(String cataloge){
		
		String[] IdAndPath = null; 
		Iterator<String> iterator =getIterator();
		while (iterator.hasNext()) {
			String string = (String) iterator.next();
			IdAndPath =string.split("_");
			if(IdAndPath[0].equals(cataloge)){
				return true;//����
			}//end if
		}//end while
		
		return false;//������
	}
	
	public boolean isEmpty(){
		return textLine.isEmpty();
	}//end
	
	public void addCatalogeAndPath(String cataloge){
		cataloge += "_"+cataloge+".txt"; 
		textLine.add(cataloge);
	}//end
	
	
	//toString
	public String toString(){
		String text = "";
		Iterator<String> iterator = getIterator();
		while (iterator.hasNext()) {
			String string = (String) iterator.next();
			text += string+"_\n";
		}
		
		return text; 
	}//end
	
	//��textLineд���ļ�
	public void writeCatalogeAndPathToFile() throws Exception{
		String text = toString();
		communinateWithFile.writeDataToFile(text);
	}//end
	
	
	
	
	//������еķ���
	public String[] getAllCataloge(){
		String[] IdAndPath = null;
		int count = 0;
		String[] cataloge = new String[textLine.size()];
		Iterator<String> iterator =getIterator();
		while (iterator.hasNext()) {
			String string = (String) iterator.next();
			IdAndPath =string.split("_");
			cataloge[count++] = IdAndPath[0];
		}//end while
		
		return cataloge;
	}//end
}
