package communiate;

import java.util.Iterator;
import java.util.Vector;

import Tools.CommuninateWithFile;
import object.BorrowCount;

public class BorrowCountList {
	private Vector<String> borrowCounts = new Vector<String>();
	private CommuninateWithFile communinateWithFile = new CommuninateWithFile(".\\BorrowCcountList.txt");
	private static BorrowCountList singleInstance = null;
	
	//���췽�������ļ��ж�ȡ������borrowCounts
	private BorrowCountList() throws Exception{
		String text;
		String[] textLine;
		
		communinateWithFile.writeDataToFile("", true);//ȷ���ļ�����
		text = communinateWithFile.readDataFromFile();
		if(text!=""){
			textLine = text.split("\n");
			for(int i=0;i<textLine.length;i++){
				borrowCounts.add(textLine[i]);
			}//endfor
		}//endif
	}//end
	
	//��ȡ����
	public static BorrowCountList getSingleInstance() throws Exception{
		if(singleInstance ==null){
			return singleInstance = new BorrowCountList();
		}else{
			return singleInstance;
		}//endif
	}//end
	
	
	//��borrowCounts�е�����toString
	public String toString(){
		Iterator<String> iterator = borrowCounts.iterator();
		String text = "";
		
		while (iterator.hasNext()) {
			String string = (String) iterator.next();
			text = string+"\n";
		}//endwhile
		
		return text;
	}//end
	
	
	//�����ض����ͼ��Ľ������
	public void addCount(String code){
		Iterator<String> iterator = borrowCounts.iterator();
		String[] itemAndCount;
		
		int count = 0;
		while (iterator.hasNext()) {
			String string = (String) iterator.next();
			itemAndCount = string.split("_");
			if(itemAndCount[0].equals(code)){
				count = Integer.parseInt(itemAndCount[1]);
				count++;
				iterator.remove();
			}//endif
		}//endwhile
		
	//���ӵ�borrowCount��
		borrowCounts.add(code+"_"+count+"_");
	}//end
	
	
	//д���ļ�
	public void writeBorrowCountsToFile() throws Exception{
		communinateWithFile.writeDataToFile(toString());
	}//end
	
	
	//���ҽ��Ĵ�������5��
	public Vector<BorrowCount> TheFiveTopBorrow(){
		Vector<BorrowCount> topFive = new Vector<BorrowCount>();
		BorrowCount[] borrowCountArray = new BorrowCount[borrowCounts.size()];
		Iterator<String> iterator = borrowCounts.iterator();
		int raw = 0;
		
		while (iterator.hasNext()) {
			String string = (String) iterator.next();
			borrowCountArray[raw++] = new BorrowCount(string);
		}//endwhile
		
		//�������������
		for(int i = 0;i<borrowCountArray.length&&i<5;i++){
			BorrowCount max = borrowCountArray[i];
			for(int j = i;j<borrowCountArray.length;j++){
				if(max.CompareCounts(borrowCountArray[j])==-1){
					max = borrowCountArray[j];
					location = j;
				}//endif
				
				topFive.add(max);
				borrowCountArray[location] = null;
			}//endfor(�ڲ�)
		}//endfor(���)
		
		return topFive;
	}//end
	
}



