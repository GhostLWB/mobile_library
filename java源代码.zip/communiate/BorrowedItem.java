
package communiate;
import java.util.Iterator;
import java.util.Vector;

import Tools.CommuninateWithFile;
import Tools.MakeItemFromString;
import object.Item;

public class BorrowedItem {
	private String ID;
	private Vector<Item> borrowedItems = new Vector<Item>();
	private CommuninateWithFile communinateWithFile;
	
	//��ɶ�ID,path.borrowedItems�ĳ�ʼ��
	public BorrowedItem(String initialID) throws Exception{
		ID = initialID;
		MatchIDWithBorrowerItem matchIDWithBorrowerItem = MatchIDWithBorrowerItem.getSingleInstance();//��ȡ��IDƥ���·��
		communinateWithFile = new CommuninateWithFile(matchIDWithBorrowerItem.getMacthedPath(initialID));
		finishBoorowedItems();
	}
	
	
	public String getID() {
		return ID;
	}
	
	
	
	//��ɶ�BorrowedItems�ĳ�ʼ��
	private void finishBoorowedItems() throws Exception{
		String[] textLine;
		String text;
		communinateWithFile.writeDataToFile("", true);
		text = communinateWithFile.readDataFromFile();
			if(text!=""){
				textLine = text.split("\n");
				for (int i = 0; i < textLine.length; i++) {
					borrowedItems.add(MakeItemFromString.makeItemFromString(textLine[i]));
				}//endfor
			}//endif
	}
	
	
	public Iterator<Item> getIterator(){
		return borrowedItems.iterator();
	}
	//��borrowedItems�е�items��ToString
	public String toString(){
		String text = "";
		Iterator<Item> iterator = getIterator();
		while (iterator.hasNext()) {
			Item item = (Item) iterator.next();
			text += item.toString()+"_\n";
		}
		return text;
	}
	//��borrowedItems������items
	public void addItem(Item item) {
		borrowedItems.add(item);
	}
	//�Ƴ��ض���items
	public boolean removeItem(String code) throws Exception {
		
		Item item;
		Iterator<Item> iterator = getIterator();
		
		while (iterator.hasNext()) {
			item = (Item) iterator.next();
			if (item.getCode().equals(code)) {
				iterator.remove();
				writeBorrowedItemsToFile();
				return true;
			}//endif
		}//endif
		
		return false;
	}
	//�������ֲ����ض�����Ŀ��
	public Vector<Item> searchItem(String itemName) {
		Item  item;
		Vector<Item> items = new Vector<Item>();
		Iterator<Item> iterator = getIterator();
		
		while (iterator.hasNext()) {
			item = (Item) iterator.next();
			if (item.getName().equals(itemName)) {
				items.add(item);
			}
		}
		return items;
	}
	
	//����Ŀд���ض����ļ���
	public void writeBorrowedItemsToFile() throws Exception{
		String text = toString();
		communinateWithFile.writeDataToFile(text);
	}
	
	
}
