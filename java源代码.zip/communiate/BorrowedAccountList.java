package communiate;
import java.util.Iterator;

import java.util.Vector;

import Tools.CommuninateWithFile;
import Tools.MakeAccountFromString;
import object.BorrowerAccount;

public class BorrowedAccountList {
	
	private Vector<BorrowerAccount> borrowedAccountList = null;
	private CommuninateWithFile communinateWithFile;
	
	//��ɶ�borrowedAccountList�ĳ�ʼ��
	public BorrowedAccountList() throws Exception{
		borrowedAccountList = new Vector<BorrowerAccount>();
		communinateWithFile = new CommuninateWithFile(".\\BorrowedAccountList.txt");
		finishBoorowedAccountList();
	}
	
	
	
	//��ɶ�borrowedAccountList�ĳ�ʼ��
	private void finishBoorowedAccountList() throws Exception{
		String[] textLine;
		String text;
		communinateWithFile.writeDataToFile("", true);//ȷ���ļ�����
		text = communinateWithFile.readDataFromFile();
		if(text!=""){
			textLine = text.split("\n");
			for (int i = 0; i < textLine.length; i++) {
				borrowedAccountList.addElement(MakeAccountFromString.getBorrowerAccount(textLine[i]));
			}//endfor
		}//endif
	}
	
	
	public Iterator<BorrowerAccount> getIterator(){
		return borrowedAccountList.iterator();
	}
	//��borrowedAccountList�е�BorrowedAccount��ToString
	public String toString(){
		String text = "";
		Iterator<BorrowerAccount> iterator = getIterator();
		while (iterator.hasNext()) {
			BorrowerAccount borrowerAccount = (BorrowerAccount) iterator.next();
			text += borrowerAccount.toString()+"_\n";
		}
		return text;
	}
	//��borrowedAccountList������BorrowedAccount
	public void addBorrowerAccount(BorrowerAccount borrowedAccount) {
		borrowedAccountList.add(borrowedAccount);
	}
	
	//�Ƴ��ض���BorrowedAccount
	public boolean removeBorrowerAccount(String ID) {
		
		BorrowerAccount borrowerAccount;
		Iterator<BorrowerAccount> iterator = getIterator();
		
		while (iterator.hasNext()) {
			borrowerAccount = (BorrowerAccount) iterator.next();
			if (borrowerAccount.equals(ID)) {
				iterator.remove();
				return true;
			}
		}
		
		return false;
	}
	
	
	//����ID�����ض��˻�
	public BorrowerAccount searchBorrowerAccountByID(String ID) {
		BorrowerAccount borrowerAccount; 
		Iterator<BorrowerAccount> iterator = getIterator();
		
		while (iterator.hasNext()) {
			borrowerAccount = (BorrowerAccount) iterator.next();
			if (borrowerAccount.getID().equals(ID)) {
				return borrowerAccount;
			}
		}
		return null;
	}
	
	//���˻�д���ض����ļ���
	public void writeBorrowerAccountToFile() throws Exception{
		String text = toString();
		communinateWithFile.writeDataToFile(text);
	}
	
	//�����ߵ�½
	public boolean borrowerLogin(String ID,String passWord){
		BorrowerAccount borrowerAccount = searchBorrowerAccountByID(ID);
		if(borrowerAccount==null){
			return false;
		}//endif
		if(!borrowerAccount.getPassWords().equals(passWord)){
			return false;
		}//endif
		
		return true;
	}//end
}
