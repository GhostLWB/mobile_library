package Tools;
import object.*;

public class MakeItemFromString {
	
	//���ַ���ת��ΪItem
	public static Item makeItemFromString(String textLine) {
		String[] text =textLine.split("_");
		if(text[0].equals("�鼮")){
			return makeBookFromString(text);
		}else{
			return makeVedioFromString(text);
		}
		
	}
	//���ַ���ת��ΪBook
	private static Book makeBookFromString(String[] initialtext) {
		Book book = new Book(initialtext[1], initialtext[3],initialtext[2],initialtext[5],initialtext[6],Integer.parseInt(initialtext[7]));
		if(initialtext[4].equals("false")){
			book.setAvaliable(false);
		}
		
		return book;
	}
	//���ַ���ת��ΪVedio
	private static Vedio makeVedioFromString(String[] initialtext) {
		Vedio vedio = new Vedio(initialtext[1], initialtext[3],initialtext[2],initialtext[4],initialtext[7],initialtext[8],Integer.parseInt(initialtext[6]));
		if(initialtext[5].equals("false")){
			vedio.setAvaliable(false);
		}
		return vedio;
	}
	
}
