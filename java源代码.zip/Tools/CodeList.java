package Tools;

import java.util.Iterator;
import java.util.Vector;

public class CodeList {
	private CommuninateWithFile communinateWithFile = new CommuninateWithFile(".\\CodeList.txt");
	private Vector<String> vector = new Vector<>();
	
	public CodeList()throws Exception{
		String text;
		String[] codeArray;
		communinateWithFile.writeDataToFile("", true);
		text = communinateWithFile.readDataFromFile();
		if(text!=""){
			codeArray = text.split("\n");
			for(int i = 0;i<codeArray.length;i++){
				vector.add(codeArray[i]);
			}//endfor
		}//endif
	}//end
	
	
	public boolean hasCode(String initialcode){
		Iterator<String> iterator = vector.iterator();
		
		while (iterator.hasNext()) {
			String string = (String) iterator.next();
			if(string.equals(initialcode)){
				return true;
			}
		
		}//endwhile}
		return false;
	}//end
	
	public void addCode(String code){
		vector.add(code);
	}//end
	
	public String toString(){
		Iterator<String> iterator = vector.iterator();
		String text = "";
		while (iterator.hasNext()) {
			String string = (String) iterator.next();
			text += string+"\n";
		}
		
		return text;
	}//end
	
	
	
	public void writeDataToFile()throws Exception{
		
		String text = toString();
		communinateWithFile.writeDataToFile(text);
	}//end
}