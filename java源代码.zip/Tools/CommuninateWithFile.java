package Tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class CommuninateWithFile {
	private String filename;
	private BufferedReader br = null;
	private FileReader fr = null;
	
	private FileWriter fWriter =null;
	private BufferedWriter bufferedWriter = null;

	public CommuninateWithFile(String initalFilename) {
		filename = initalFilename;
	}
	//����ļ�·��
	public String getFilename() {
		return filename;
	}
	//ȷ���ļ�·��
	public void setFilename(String newFilename) {
		filename = newFilename;
	}
	
	//���ļ�����ͷ��ʼ���ļ�ȫ��������
	public String readDataFromFile() throws Exception{
		fr = new FileReader(filename);
		br = new BufferedReader(fr);
		String text ="";
		String temp;
		
		
		while((temp=br.readLine())!=null){				//�ļ���ȡ
			text +=temp + "\n";
		}
		br.close();
		return text;			
	}
	//д���ļ���appendΪfalse��ͷ��ʼд��,appendΪtrue��ĩβ��ʼд��
	public void writeDataToFile(String text,boolean append) throws Exception {
		fWriter = new FileWriter(filename, append);
		bufferedWriter = new BufferedWriter(fWriter);
		
		String[] textLine =text.split("\n");
		for(int i=0;i<textLine.length;i++){
			bufferedWriter.write(textLine[i], 0, textLine[i].length());
			}
		
		
		bufferedWriter.flush();
		bufferedWriter.close();
	}
	//��ͷ��ʼ��������
	public void writeDataToFile(String text)throws Exception{
		
		fWriter = new FileWriter(filename);
		bufferedWriter = new BufferedWriter(fWriter);
		
		String[] textLine =text.split("\n");
		for(int i=0;i<textLine.length-1;i++){
			bufferedWriter.write(textLine[i]);
			bufferedWriter.newLine();
			}
		bufferedWriter.write(textLine[textLine.length-1]);
		bufferedWriter.flush();
		bufferedWriter.close();
	}

}
